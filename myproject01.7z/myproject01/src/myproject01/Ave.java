package myproject01;

public class Ave extends Animal {
	
	public Ave(String nome) {
		super(nome);
	}
}
