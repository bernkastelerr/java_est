package myproject01;

public class MinhaClasse {
	public static void main(String[] args) {
		Ave a = new Ave("Papagaio");
		a.imprimeNome();
		
		Mamifero b = new Mamifero("Macaco");
		b.imprimeNome();
	}
}
