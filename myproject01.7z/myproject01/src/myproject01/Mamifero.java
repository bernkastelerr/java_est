package myproject01; 

public class Mamifero extends Animal{

	public Mamifero(String nome) {
		super(nome);
	}

}
