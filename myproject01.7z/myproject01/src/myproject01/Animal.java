package myproject01; // Serve para organizar e modularizar o código

public class Animal { // public serve para ser acessado por outras classes

	private String nome; // Atributo (variável no inicio) só pode ser chamada dentro da classe animal
	
	public void imprimeNome() { // Métodos são manipuladores de atributos (Nesse caso ele imprime a variavel nome)
		System.out.print("O nome do animal é ");
		System.out.println(nome);
	}
	
	public Animal () {}
	
	public Animal (String nome) { // Método Construtor
		this.nome = nome;
	}
}
