package comportamento;

import estrutura.Banco;
import estrutura.Agencia;

public class SistemaBancario{

	public static void main(String[] args) {
		Banco banco1 = new Banco();
		banco1.setNome("Bradesco");
		
		Agencia agencia1 = new Agencia();
		Agencia agencia2 = new Agencia();
		
		agencia1.setNome("Agencia 1");
		agencia2.setNome("Agencia 2");
		
		banco1.addAgencia(agencia1);
		banco1.addAgencia(agencia2);
		
		System.out.println(banco1);
	}

}
