package estrutura;

public class Agencia {
	private Banco b;
	private String nome;
	
	
	public Banco getBanco() {
		return b;
	}

	public void setBanco(Banco b) {
		this.b = b;
	}

	
	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public String toString() {
		return this.nome;
	}
}