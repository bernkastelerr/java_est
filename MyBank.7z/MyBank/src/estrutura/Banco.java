package estrutura;

import java.util.ArrayList;

public class Banco {
	private ArrayList<Agencia> agencias = new ArrayList<Agencia>();
	private String Nome;
	
	public void addAgencia(Agencia a) {
		agencias.add(a);
	}

	public String getNome() {
		return Nome;
	}
	
	public void setNome (String nome) {
		this.Nome = nome;
	}
	
	public void setAgencias (ArrayList<Agencia> agencias) {
		this.agencias = agencias;
	}

	// Override
	public String toString() {
		return "Nome do banco: " + getNome() + " Agencias: " + agencias;
	}
}