package estrutura;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.Set;

public class Banco {
	private ArrayList<Agencia> agencias = new ArrayList<Agencia>();
	private Set<Cliente> clientes = new HashSet<Cliente>();
	private String Nome;
	
	public void addCliente (Cliente cliente) {
		clientes.add(cliente);
	}
	public void addAgencia(Agencia agencia) {
		agencias.add(agencia);
	}

	public String getNome() {
		return Nome;
	}
	
	public void setNome (String nome) {
		this.Nome = nome;
	}
	
	public void setAgencias (ArrayList<Agencia> agencias) {
		this.agencias = agencias;
	}

	// Override
	public String toString() {
		return "Banco: " + getNome() + "\nAgencias: " + agencias + "\nClientes: " + clientes;
	}
}