package estrutura;

public class Cliente {
	
	private String nome;
	private String cpf;
	
	
	public Cliente() {}
	
	public Cliente(String nome) { // Metodo Construtor
		this.nome = nome;
	}
	
	
	public String getNome() {
		return nome;
	}
	
	public void setNome (String nome) {
		this.nome = nome;
	}

	
	public String getCpf() {
		return cpf;
	}

	public void setCpf(String cpf) {
		this.cpf = cpf;
	}
	
	
	public String toString() {
		return this.nome;
	}
	
	@Override
	public boolean equals(Object obj) {
		Cliente cli = (Cliente) obj;
		return this.getCpf().equals(cli.getCpf());
	}
	
	@Override
	public int hashCode() {
		return getCpf().hashCode();
	}
}
